<?php
include("config.php");
extract($_POST);
$sql = "INSERT INTO `data`(`firstname`, `lastname`, `dob`, `gender`, `phone`, `email`, `address`, `city`, `pincode`, `state`) 
VALUES ('".$firstname."','".$lastname."','".$dob."','".$gender."','".$phone."','".$email."','".$address."','".$city."','".$pincode."','".$state."')";
$result = $mysqli->query($sql);
if(!$result){
    die("Couldn't enter data: ".$mysqli->error);
}
echo "Thank You For Contacting Us ";
$mysqli->close();
?>